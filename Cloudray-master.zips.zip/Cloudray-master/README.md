# Cloudray-assignment
>  Node project for assignment given by cloudray

## Installation
[Node.js](https://nodejs.org/en/) required
```bash
npm install
```


## Usage

```js
npm test
```
Example output:
```js
output.json
```

## Contribute
Did you find a bug? Do you have an idea or a feature request? [Open an issue!](https://github.com/bhanuagarwal73/Cloudray/issues)

## License
[ISC](https://github.com/bhanuagarwal73/)